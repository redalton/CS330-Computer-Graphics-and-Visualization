﻿#include <GL/glew.h>        // GLEW library
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>     // GLFW library
#include "camera.h"
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "BScott CS 330 Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nVertices;
        glm::vec3 objectColor;
    };
    
    // camera
    Camera gCamera(glm::vec3(0.0f, 5.0f, 25.0f));

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool perspectiveMode = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh cupBodyMesh;
    GLMesh cupHandleMesh; //Mesh for torus
    GLMesh tableMesh; //Mesh for plane
    GLMesh backgroundMesh; //Mesh for backdrop plane
    GLMesh vaseMesh; //Mesh for vase
    GLMesh flowerMesh1;
    GLMesh flowerMesh2;
    GLMesh flowerMesh3;
    GLMesh tableFlowerMesh;
    GLMesh saucerMesh; //torus mesh for the saucer
    GLMesh leafMesh;
    GLMesh petalMesh;
    GLMesh stemMesh;

    GLMesh keyLightMesh;
    GLMesh fillLightMesh;

    // Texture
    GLuint cupTextureID;
    GLuint woodTextureID;
    GLuint metalTextureID;
    GLuint flowerTextureID;
    GLuint leafTextureID;
    glm::vec2 cupScale(1.0f, 1.0f);
    glm::vec2 woodScale(1.0f, 1.0f);
    glm::vec2 metalScale(2.0f, 2.0f);
    glm::vec2 flowerScale(5.0f, 2.0f);
    glm::vec2 leafScale(1.0f, 1.0f);
    GLint cupWrapMode = GL_REPEAT;
    GLint woodWrapMode = GL_REPEAT;
    GLint metalWrapMode = GL_REPEAT;
    GLint flowerWrapMode = GL_WRAP_BORDER;
    GLint leafWrapMode = GL_REPEAT;

    const int leafCount = 2;
    glm::vec3 leafPositions[leafCount] = { glm::vec3(-0.5f, -0.5f, -2.5f),glm::vec3(2.5f, 2.0f, -2.0f)};

    
    // Shader program
    GLuint meshProgramId;
    GLuint keyLightProgramId;
    GLuint fillLightProgramId;

    struct GLLight {
        glm::vec3 lightPosition;
        glm::vec3 lightScale;
        glm::vec3 lightColor;
        float lightIntensity;
    };

    GLLight keyLight;
    GLLight fillLight;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateLight(GLLight& light, glm::vec3 pos, glm::vec3 scale, glm::vec3 color, float intensity);
void UCreateCube(GLMesh& mesh);
void UCreatePlane(GLMesh& mesh, glm::vec3 color);
void UCreateCircle(GLMesh& mesh, float radius, glm::vec3 color);
void UCreateCylinder(GLMesh& mesh, float height, float upperRadius, float lowerRadius, glm::vec3 color);
void UCreateTorus(GLMesh& mesh, float torusRadius, float tubeRadiusInput, glm::vec3 color);
void UCreateSphere(GLMesh& mesh, float radius, glm::vec3 color);
vector<float> getCylinderVertices(float height, float upperRadius, float lowerRadius, float numberOfVerts);
vector<float> getCircleVertices(float radius, int resolution);
vector<float> getTorusVertices(float torusRadius, float tubeRadius, int numberOfSlices, int tubeResolution);
vector<float> getSphereVertices(float radius, int horizontalSlices, int verticalSlices);
vector<GLushort> getCylinderTriangles(int numbOfVerts);
vector<GLushort> getTorusTriangles(int numberOfSlices, int tubeResolution);
vector<GLushort> getSphereTriangles(int horizontalSlices, int verticalSlices);
vector<GLushort> getCircleTriangles(int resolution);
bool UCreateTexture(const char* filename, GLuint& textureId);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void UDestroyMesh(GLMesh& mesh);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
        vertexTextureCoordinate = textureCoordinate;
    }
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 keyLightColor;
uniform vec3 keyLightPos;
uniform vec3 fillLightColor;
uniform vec3 fillLightPos;
uniform vec3 viewPosition;
uniform float keySpecularIntensity;
uniform float fillSpecularIntensity;
uniform float keyHighlightSize;
uniform float fillHighlightSize;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float keyStrength = 0.1f; // Set ambient or global lighting strength
    float fillStrength = 0.1f;
    vec3 keyAmbient = keyStrength * keyLightColor; // Generate ambient light color
    vec3 fillAmbient = fillStrength * fillLightColor;

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 keyLightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    vec3 fillLightDirection = normalize(fillLightPos - vertexFragmentPos);

    float keyImpact = max(dot(norm, keyLightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    float fillImpact = max(dot(norm, fillLightDirection), 0.0);

    vec3 keyDiffuse = keyImpact * keyLightColor; // Generate diffuse light color
    vec3 fillDiffuse = fillImpact * fillLightColor;

    //Calculate Specular lighting*/
    //float specularIntensity = 1.0f; // Set specular light strength
    //float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 keyReflectDir = reflect(-keyLightDirection, norm);// Calculate reflection vector
    vec3 fillReflectDir = reflect(-fillLightDirection, norm);// Calculate reflection vector

    //Calculate specular component
    float keySpecularComponent = pow(max(dot(viewDir, keyReflectDir), 0.0), keyHighlightSize);
    float fillSpecularComponent = pow(max(dot(viewDir, fillReflectDir), 0.0), fillHighlightSize);
    vec3 keySpecular = keySpecularIntensity * keySpecularComponent * keyLightColor;
    vec3 fillSpecular = fillSpecularIntensity * fillSpecularComponent * fillLightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (keyAmbient + fillAmbient + keyDiffuse + fillDiffuse + keySpecular + fillSpecular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);

/* Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

    void main()
    {
        fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
    }
);


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    //Key Light
    glm::vec3 keyLightPos(7.0f, 15.0f, 4.0f);
    glm::vec3 keyLightScale(1.0f);
    glm::vec3 keyLightColor(0.94f, 0.95f, 0.74f);

    //Fill Light
    glm::vec3 fillLightPos(4.0f, 0.0f, -5.0f);
    glm::vec3 fillLightScale(1.0f);
    glm::vec3 fillLightColor(1.0f, 1.0f, 1.0f);

    UCreateLight(keyLight, keyLightPos, keyLightScale, keyLightColor, 1.0f);
    UCreateLight(fillLight, fillLightPos, fillLightScale, fillLightColor, 0.1f);

    // Create the mesh
    UCreateCylinder(cupBodyMesh, 2, 1, 0.75f, glm::vec3(1.0f, 1.0f, 1.0f)); // Create the vbo for the cylinder
    UCreateTorus(cupHandleMesh, 4, 1, glm::vec3(1.0f, 1.0f, 1.0f)); //Create the vbo for the torus
    UCreateCylinder(saucerMesh, 0.5f, 1, 1, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreatePlane(tableMesh, glm::vec3(0.64f, 0.16f, 0.16f)); //Create the vbo for the plane
    UCreatePlane(backgroundMesh, glm::vec3(0.64f, 0.16f, 0.16f)); //Create the vbo for the backdrop plane
    UCreateCylinder(vaseMesh, 2, 1, 0.75f, glm::vec3(0.7f, 0.7f, 0.7f)); //Create the vbo for the vase
    UCreateSphere(flowerMesh1, 3, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateSphere(flowerMesh2, 3, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateSphere(flowerMesh3, 3, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateSphere(tableFlowerMesh, 2, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateCircle(leafMesh, 0.5f, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateCylinder(stemMesh, 4, .25f, .25f, glm::vec3(.01f, 1.0f, 0.01f));

    UCreateSphere(keyLightMesh, 1, glm::vec3(1.0f, 1.0f, 1.0f));
    UCreateSphere(fillLightMesh, 1, glm::vec3(1.0f, 1.0f, 1.0f));

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, meshProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, keyLightProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, fillLightProgramId))
        return EXIT_FAILURE;

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(meshProgramId);

    // Load texture
    const char* cupFilename = "../resources/textures/cup.png"; //Teacup texture
    if (!UCreateTexture(cupFilename, cupTextureID))
    {
        cout << "Failed to load texture " << cupFilename << endl;
        return EXIT_FAILURE;
    }

    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(meshProgramId, "uTexture"), 0);

    
    const char* woodFilename = "../resources/textures/woodPlanks.jpg"; //wood texture
    if (!UCreateTexture(woodFilename, woodTextureID))
    {
        cout << "Failed to load texture " << woodFilename << endl;
        return EXIT_FAILURE;
    }

    // We set the texture as texture unit 1
    glUniform1i(glGetUniformLocation(meshProgramId, "uTexture2"), 1);

    const char* metalFilename = "../resources/textures/metal.jpg"; //metal
    if (!UCreateTexture(metalFilename, metalTextureID))
    {
        cout << "Failed to load texture " << metalFilename << endl;
        return EXIT_FAILURE;
    }

    // We set the texture as texture unit 1
    glUniform1i(glGetUniformLocation(meshProgramId, "uTexture2"), 2);

    const char* flowerFilename = "../resources/textures/flower.png"; //flower
    if (!UCreateTexture(flowerFilename, flowerTextureID))
    {
        cout << "Failed to load texture " << flowerFilename << endl;
        return EXIT_FAILURE;
    }

    // We set the texture as texture unit 1
    glUniform1i(glGetUniformLocation(meshProgramId, "uTexture2"), 3);

    const char* leafFilename = "../resources/textures/leaf.png"; //leaf
    if (!UCreateTexture(leafFilename, leafTextureID))
    {
        cout << "Failed to load texture " << leafFilename << endl;
        return EXIT_FAILURE;
    }

    // We set the texture as texture unit 1
    glUniform1i(glGetUniformLocation(meshProgramId, "uTexture2"), 4);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;


        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(cupBodyMesh);
    UDestroyMesh(cupHandleMesh);
    UDestroyMesh(tableMesh);
    UDestroyMesh(vaseMesh);
    UDestroyMesh(backgroundMesh);
    UDestroyMesh(flowerMesh1);
    UDestroyMesh(flowerMesh2);
    UDestroyMesh(flowerMesh3);
    UDestroyMesh(tableFlowerMesh);
    UDestroyMesh(saucerMesh);
    UDestroyMesh(leafMesh);
    UDestroyMesh(stemMesh);

    UDestroyMesh(keyLightMesh);
    UDestroyMesh(fillLightMesh);

    // Release texture
    UDestroyTexture(cupTextureID);
    UDestroyTexture(woodTextureID);
    UDestroyTexture(metalTextureID);

    // Release shader program
    UDestroyShaderProgram(meshProgramId);
    UDestroyShaderProgram(keyLightProgramId);
    UDestroyShaderProgram(fillLightProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    //updated camera to move view up and down using q and e keys.
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        perspectiveMode = true;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        perspectiveMode = false;

    if (glfwGetKey(window, GLFW_KEY_PAGE_UP) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(0, 1, 0);
    if (glfwGetKey(window, GLFW_KEY_PAGE_DOWN) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(0, -1, 0);
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(0, 0, 1);
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(0, 0, -1);
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(-1, 0, 0);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        keyLight.lightPosition += 2.5f * gDeltaTime * glm::vec3(1, 0, 0);

    
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    //initializing model
    glm::mat4 model;

    // Set the shader to be used
    glUseProgram(meshProgramId);

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(meshProgramId, "model");
    GLint viewLoc = glGetUniformLocation(meshProgramId, "view");
    GLint projLoc = glGetUniformLocation(meshProgramId, "projection");

    glm::mat4 projection;
    if (perspectiveMode) {
        // Creates a perspective projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        // Creates a orthographic projection
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
    }
    
    /**********************************************
    *                                             *
    *            Cylinder/ Teacup                 *
    *                                             *
    * ********************************************/
    
    //Transform and draw the cylinder
    glBindVertexArray(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(cupBodyMesh.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    float cylinderRotation = -90.0f * (3.1415 / 180);
    model = glm::rotate(model, cylinderRotation, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(-2.5f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Reference matrix uniforms from the mesh Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(meshProgramId, "objectColor");
    GLint viewPositionLoc = glGetUniformLocation(meshProgramId, "viewPosition");

    //Key Light parameters
    GLint keyLightColorLoc = glGetUniformLocation(meshProgramId, "keyLightColor");
    GLint keyLightPositionLoc = glGetUniformLocation(meshProgramId, "keyLightPos");
    GLint keyLightIntensityLoc = glGetUniformLocation(meshProgramId, "keySpecularIntensity");
    GLint keyHighlightLoc = glGetUniformLocation(meshProgramId, "keyHighlightSize");

    //Fill light parameters
    GLint fillLightColorLoc = glGetUniformLocation(meshProgramId, "fillLightColor");
    GLint fillLightPositionLoc = glGetUniformLocation(meshProgramId, "fillLightPos");
    GLint fillLightIntensityLoc = glGetUniformLocation(meshProgramId, "fillSpecularIntensity");
    GLint fillHighlightLoc = glGetUniformLocation(meshProgramId, "fillHighlightSize");

    // Pass color, light, and camera data to the mesh Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, cupBodyMesh.objectColor.r, cupBodyMesh.objectColor.g, cupBodyMesh.objectColor.b);
    glUniform3f(keyLightColorLoc, keyLight.lightColor.r, keyLight.lightColor.g, keyLight.lightColor.b);
    glUniform3f(keyLightPositionLoc, keyLight.lightPosition.x, keyLight.lightPosition.y, keyLight.lightPosition.z);
    glUniform1f(keyLightIntensityLoc, keyLight.lightIntensity);
    glUniform1f(keyHighlightLoc, 16.0f);
    glUniform3f(fillLightColorLoc, fillLight.lightColor.r, fillLight.lightColor.g, fillLight.lightColor.b);
    glUniform3f(fillLightPositionLoc, fillLight.lightPosition.x, fillLight.lightPosition.y, fillLight.lightPosition.z);
    glUniform1f(fillLightIntensityLoc, fillLight.lightIntensity);
    glUniform1f(fillHighlightLoc, 16.0f);

    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    
    //Apply the texture with given uvscale
    GLint UVScaleLoc1 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc1, 1, glm::value_ptr(cupScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cupTextureID);

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, cupBodyMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender

    
      /**********************************************
    *                                             *
    *              Torus / Teacup handle          *
    *                                             *
    * ********************************************/
    
    //Transform and draw the torus
    glBindVertexArray(0);
    glActiveTexture(0);
    //Draw the torus
    glBindVertexArray(cupHandleMesh.vao); //Bind the torus mesh

    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(0.15f, 0.15f, 0.2f));
    // 2. Rotates shape by 15 degrees in the x axis
    model = glm::rotate(model, 0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(-10.0f, 0.0f, 0.0f));

    //model = glm::translate(model, glm::vec3(0.5f, 0.5f, 0.0f));

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    GLint UVScaleLoc2 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc2, 1, glm::value_ptr(cupScale));

    glUniform3f(objectColorLoc, cupHandleMesh.objectColor.r, cupHandleMesh.objectColor.g, cupHandleMesh.objectColor.b);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cupTextureID);

   
    glDrawElements(GL_TRIANGLES, cupHandleMesh.nIndices, GL_UNSIGNED_SHORT, NULL);
    //glDrawArrays(GL_TRIANGLE_STRIP, 0, 190);


     /**********************************************
   *                                             *
   *            Cylinder/ Teacup Saucer          *
   *                                             *
   * ********************************************/
   //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(saucerMesh.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    float saucerRotation = -90.0f * (3.1415 / 180);
    model = glm::rotate(model, saucerRotation, glm::vec3(1.0f, 0.0f, 0.0f));
    model = glm::scale(model, glm::vec3(2.0f, 2.0f, 0.25f));
    model = glm::translate(model, glm::vec3(-1.25f, 0.0f, -4.0f));

    // Model matrix: transformations are applied right-to-left order

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cupTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc9 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc9, 1, glm::value_ptr(flowerScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, flowerMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender
    

    /**********************************************
    *                                             *
    *               Plane / Table                 *
    *                                             *
    * ********************************************/

    

    //Transform and draw the plane
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the plane's mesh's VAO
    glBindVertexArray(tableMesh.vao);

    //transform for Plane
    model = glm::mat4(1.0f);
    float planeRotation = -90.0f * (3.1415 / 180);
    model = glm::rotate(model, planeRotation, glm::vec3(1.0f, 0.0f, 0.0f));
    model = glm::rotate(model, planeRotation, glm::vec3(0.0f, 0.0f, 1.0f));
    model = glm::scale(model, glm::vec3(15.0f, 20.0f, 1.0f));
    model = glm::translate(model, glm::vec3(-0.5f, -.5f, -1.0f));
    // Model matrix: transformations are applied right-to-left order

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    
    glUniform3f(objectColorLoc, tableMesh.objectColor.r, tableMesh.objectColor.g, tableMesh.objectColor.b);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, woodTextureID);

    GLint UVScaleLoc3 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc3, 1, glm::value_ptr(woodScale));

   // glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, tableMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle    

    

     /**********************************************
    *                                             *
    *               Plane / Backdrop              *
    *                                             *
    * ********************************************/

    

    //Transform and draw the plane
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the plane's mesh's VAO
    glBindVertexArray(backgroundMesh.vao);

    //transform for Plane
    model = glm::mat4(1.0f);
    float bPlaneRotation = 0.0f * (3.1415 / 180);
    model = glm::rotate(model, bPlaneRotation, glm::vec3(0.0f, 0.0f, 1.0f));
    //model = glm::rotate(model, bPlaneRotation, glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::scale(model, glm::vec3(20.0f, 20.0f, 1.0f));
    model = glm::translate(model, glm::vec3(-0.5f, -0.1f, -7.5f));
    // Model matrix: transformations are applied right-to-left order

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform3f(objectColorLoc, backgroundMesh.objectColor.r, backgroundMesh.objectColor.g, backgroundMesh.objectColor.b);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, woodTextureID);

    GLint UVScaleLoc4 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc4, 1, glm::value_ptr(woodScale));

    // glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
     // Draws the triangles
    glDrawElements(GL_TRIANGLES, backgroundMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle    

    

     /**********************************************
    *                                             *
    *            Cylinder/ Vase                   *
    *                                             *
    * ********************************************/

    

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(vaseMesh.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(1.0f, 1.5f, 1.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    cylinderRotation = -90.0f * (3.1415 / 180);
    model = glm::rotate(model, cylinderRotation, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(2.5f, 3.0f, 0.3f));
    // Model matrix: transformations are applied right-to-left order

    glUniform3f(objectColorLoc, vaseMesh.objectColor.r, vaseMesh.objectColor.g, vaseMesh.objectColor.b);

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, metalTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc5 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc5, 1, glm::value_ptr(metalScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, vaseMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender

    
    
     /**********************************************
    *                                             *
    *           Sphere/ Flowerhead                *
    *                                             *
    * ********************************************/

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(flowerMesh1.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
    // 2. Rotates shape by 15 degrees in the x axis
    float sphereRotation = (-90.0f * (3.1415 / 180));
    
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(4.0f, 7.0f, -6.0f));
    model = glm::rotate(model, sphereRotation, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, float(180.0f * (3.1415 / 180)), glm::vec3(0.0f, 0.0f, 1.0f));
    // Model matrix: transformations are applied right-to-left order

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, flowerTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc6 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc6, 1, glm::value_ptr(flowerScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, flowerMesh1.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender

     /**********************************************
    *                                             *
    *           Sphere/ Flowerhead  2             *
    *                                             *
    * ********************************************/

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(flowerMesh2.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
    // 2. Rotates shape by 15 degrees in the x axis
    
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(7.0f, 8.0f, -10.0f));
    model = glm::rotate(model, sphereRotation, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, float(180.0f * (3.1415 / 180)), glm::vec3(0.0f, 0.0f, 1.0f));
    // Model matrix: transformations are applied right-to-left order

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, flowerTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc7 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc7, 1, glm::value_ptr(flowerScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, flowerMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender


     /**********************************************
    *                                             *
    *           Sphere/ Flowerhead      3         *
    *                                             *
    * ********************************************/

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(flowerMesh3.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(0.4f, 0.4f, 0.4f));
    
    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(9.0f, 7.0f, -6.0f));
    model = glm::rotate(model, sphereRotation, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, float(180.0f * (3.1415 / 180)), glm::vec3(0.0f, 0.0f, 1.0f));

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, flowerTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc8 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc8, 1, glm::value_ptr(flowerScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, flowerMesh3.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender

    /**********************************************
   *                                             *
   *            Sphere/ Table flower             *
   *                                             *
   * ********************************************/

  //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(tableFlowerMesh.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(.5f, .5f, .5f));
    // 2. Rotates shape by 15 degrees in the x axis
    sphereRotation = (-90.0f * (3.1415 / 180));

    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(1.0f, -0.5f, -3.0f));
    model = glm::rotate(model, sphereRotation, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, float(180.0f * (3.1415 / 180)), glm::vec3(0.0f, 0.0f, 1.0f));
    // Model matrix: transformations are applied right-to-left order

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, flowerTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLocTable = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLocTable, 1, glm::value_ptr(flowerScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, tableFlowerMesh.nIndices, GL_UNSIGNED_SHORT, NULL); 


   /**********************************************
    *                                             *
    *            Cylinder/ leaf                   *
    *                                             *
    * ********************************************/

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(leafMesh.vao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, leafTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc11 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc11, 1, glm::value_ptr(leafScale));

    for (int leaf = 0; leaf < leafCount; leaf++) {
        model = glm::mat4(1.0f);

        
        model = glm::translate(model, leafPositions[leaf]);
        model = glm::rotate(model, float(-45 * (3.1415 / 180)), glm::vec3(1.0f, 0.0f, 0.0f));

        //transforms cylinder matrix
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, leafMesh.nIndices, GL_UNSIGNED_SHORT, NULL);
    }

    //Transform and draw the cylinder
    glBindVertexArray(0);
    glActiveTexture(0);

    /**********************************************
    *                                             *
    *            Cylinder/ stem                   *
    *                                             *
    * ********************************************/

    //Activate the VBOs contained within the mesh's VAO for cylinder
    glBindVertexArray(stemMesh.vao);

    //transform for cylinder
    model = glm::mat4(1.0f);
    // 1. Scales the object by 2
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));

    // 3. Place object at the origin
    model = glm::translate(model, glm::vec3(-1.5f, -0.5f, -2.5f));
    float stemRotation = (60 * (3.1415 / 180));
    model = glm::rotate(model, stemRotation, glm::vec3(0.0f, 1.0f, .0f));
    model = glm::rotate(model, float(-10 * (3.1415 / 180)), glm::vec3(1.0f, 0.0f, 0.0f));

    //transforms cylinder matrix
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, leafTextureID);

    //Apply the texture with given uvscale
    GLint UVScaleLoc12 = glGetUniformLocation(meshProgramId, "uvScale");
    glUniform2fv(UVScaleLoc12, 1, glm::value_ptr(leafScale));

    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //Wireframe mode
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, stemMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle to create cylender



    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    /******************************************************************************************************/
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glActiveTexture(0);

    // LAMP: draw lamp
    //----------------
    glUseProgram(keyLightProgramId);
    glBindVertexArray(keyLightMesh.vao);

    

    //Transform the smaller cube used as a visual que for the light source
    

    // Retrieves and passes transform matrices to the Shader program
    GLint lightModelLoc = glGetUniformLocation(keyLightProgramId, "model");
    GLint lightViewLoc = glGetUniformLocation(keyLightProgramId, "view");
    GLint lightProjLoc = glGetUniformLocation(keyLightProgramId, "projection");

    // Reference matrix uniforms from the Lamp Shader program
    lightModelLoc = glGetUniformLocation(keyLightProgramId, "model");
    lightViewLoc = glGetUniformLocation(keyLightProgramId, "view");
    lightProjLoc = glGetUniformLocation(keyLightProgramId, "projection");

    model = glm::mat4(1.0f);
    model = glm::translate(keyLight.lightPosition) * glm::scale(keyLight.lightScale);

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(lightModelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(lightViewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(lightProjLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cupTextureID);

    //glDrawArrays(GL_TRIANGLES, 0, keyLightMesh.nVertices);

    // LAMP: draw lamp
    //----------------
    glUseProgram(fillLightProgramId);
    glBindVertexArray(fillLightMesh.vao);



    //Transform the smaller cube used as a visual que for the light source


    // Retrieves and passes transform matrices to the Shader program
    GLint fillLightModelLoc = glGetUniformLocation(fillLightProgramId, "model");
    GLint fillLightViewLoc = glGetUniformLocation(fillLightProgramId, "view");
    GLint fillLightProjLoc = glGetUniformLocation(fillLightProgramId, "projection");

    // Reference matrix uniforms from the Lamp Shader program
    fillLightModelLoc = glGetUniformLocation(fillLightProgramId, "model");
    fillLightViewLoc = glGetUniformLocation(fillLightProgramId, "view");
    fillLightProjLoc = glGetUniformLocation(fillLightProgramId, "projection");

    model = glm::mat4(1.0f);
    model = glm::translate(fillLight.lightPosition) * glm::scale(fillLight.lightScale);

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(fillLightModelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(fillLightViewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(fillLightProjLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cupTextureID);

    //glDrawArrays(GL_TRIANGLES, 0, fillLightMesh.nVertices);
    

    glBindVertexArray(0);
    glActiveTexture(0);
    
    

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

void UCreateLight(GLLight& light, glm::vec3 pos, glm::vec3 scale, glm::vec3 color, float intensity) {
    light.lightColor = color;
    light.lightPosition = pos;
    light.lightScale = scale;
    light.lightIntensity = intensity;
}

void UCreateCube(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       -0.5f, 0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       -0.5f, -0.5f, 0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       -0.5f, 0.5f, 0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       0.5f, 0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       0.5f, -0.5f, 0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
       0.5f, 0.5f, 0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
    };

    GLuint indices[] = {
        0, 1, 2,
        1, 2, 3,
        1, 4, 3,
        4, 3, 6,
        0, 1, 4,
        1, 4, 5,
        1, 3, 5,
        3, 5, 7,
        5, 4, 7,
        4, 7, 6,
        2, 3, 6,
        3, 6, 7
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreatePlane(GLMesh& mesh, glm::vec3 color)
{
    GLfloat vertArr[] = {
        //vertices           normal                     texture
        0.0f, 0.0f, 0.0f,    0.0f, 0.0f, 1.0f,   0.0f, 0.0f, //vert 0 white
        1.0f, 0.0f, 0.0f,    0.0f, 0.0f, 1.0f,   1.0f, 0.0f, //vert 1 red
        1.0f, 1.0f, 0.0f,    0.0f, 0.0f, 1.0f,   1.0f, 1.0f, //vert 2 green
        0.0f, 1.0f, 0.0f,    0.0f, 0.0f, 1.0f,   0.0f, 1.0f //vert 3 blue
    };

    GLuint indices[] = {
        0, 1, 2, 
        0, 2, 3,
        1, 2, 3,
        3, 0, 1,
        3, 2, 1,
        3, 0, 2,
        2, 1, 0,
        2, 3, 0,
        2, 1, 3
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertArr), vertArr, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    mesh.objectColor = color;
}


// Implements the UCreateMesh function
void UCreateCylinder(GLMesh& mesh, float height, float upperRadius, float lowerRadius, glm::vec3 color)
{                                
    
    const int cylinderResolution = 64; //The number of vertices in the circles on each end of the cylinder
    const int numbOfVerts = ((cylinderResolution * 2) + 2) * 8; //The number of vertices in the cylinder, including center points
    const int numbOfTriangles = (cylinderResolution * 4) * 3; //The number of triangles in the cylinder

    vector<float> vertVector = getCylinderVertices(height, upperRadius, lowerRadius, cylinderResolution);
    float vertArr[numbOfVerts]; //The array holding the vertices

    //Converts the vertex vector into the array
    for (int i = 0; i < numbOfVerts; i++) {
        vertArr[i] = vertVector[i];
    }

    vector<GLushort> lines = getCylinderTriangles(cylinderResolution); 
    GLshort indices[numbOfTriangles]; //Array holding the triangles

    //converts the triangle vector into the array
    for (int j = 0; j < numbOfTriangles; j++) {
        indices[j] = lines[j];
    }

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(vertArr) / (sizeof(vertArr[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(3, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertArr), vertArr, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    mesh.objectColor = color;
}


// Implements the UCreateMesh function
void UCreateTorus(GLMesh& mesh, float innerRadius, float tubeRadiusInput, glm::vec3 color)
{

    const int numberOfSlices = 32; //The definition of the torus. The higher the number the more circular the torus
    const int tubeResolution = 16; //The number of vertices in each slice. The higher the number the more circular the tube
    const int numbOfTriangles = numberOfSlices * tubeResolution * 2 * 3; //Calculate the number of trianlges * 3 for each index
    float torusRadius = innerRadius;
    float tubeRadius = tubeRadiusInput;

    vector<float> vertVector = getTorusVertices(torusRadius, tubeRadius, numberOfSlices, tubeResolution); //get the vertex array
    float vertArr[numberOfSlices * tubeResolution * 8]; //The array holding the vertices

    //Converts the vertex vector into the array
    for (int i = 0; i < numberOfSlices * tubeResolution * 8; i++) {
        vertArr[i] = vertVector[i];
    }
    
    vector<GLushort> triangles = getTorusTriangles(numberOfSlices, tubeResolution);
    GLshort indices[numbOfTriangles]; //Array holding the triangles

    //converts the triangle vector into the array
    for (int j = 0; j < numbOfTriangles; j++) {
        indices[j] = triangles[j];
    }

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(vertArr) / (sizeof(vertArr[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertArr), vertArr, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    mesh.objectColor = color;
}

void UCreateCircle(GLMesh& mesh, float radius, glm::vec3 color) {
    const int resolution = 64;
    vector<float> vertVector = getCircleVertices(radius, resolution);
    const int numbOfVertices = (resolution + 1) * 8;
    float vertArr[numbOfVertices];

    for (int i = 0; i < numbOfVertices; i++) {
        vertArr[i] = vertVector[i];
    }

    vector<GLushort> triangles = getCircleTriangles(resolution);
    //GLshort indices[numbOfTriangles]; //Array holding the triangles
    const int numbOfTriangles = resolution * 3;
    GLshort indices[numbOfTriangles];
    //converts the triangle vector into the array
    for (int j = 0; j < numbOfTriangles; j++) {
        indices[j] = triangles[j];
    }

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(vertArr) / (sizeof(vertArr[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertArr), vertArr, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    mesh.objectColor = color;

}

// Implements the UCreateMesh function
void UCreateSphere(GLMesh& mesh, float radius, glm::vec3 color)
{
    
    const int horizontalSlices = 32; 
    const int verticalSlices = 32; 
    float sphereRadius = radius;

    vector<float> vertVector = getSphereVertices(sphereRadius, horizontalSlices, verticalSlices); //get the vertex array
    const int indexNumb = (2 + (horizontalSlices - 1) * verticalSlices) * 8;
    float vertArr[indexNumb]; //The array holding the vertices

    //Converts the vertex vector into the array
    for (int i = 0; i < indexNumb; i++) {
        vertArr[i] = vertVector[i];
    }

    vector<GLushort> triangles = getSphereTriangles(horizontalSlices, verticalSlices);
    //GLshort indices[numbOfTriangles]; //Array holding the triangles
    const int numbOfTriangles = ((((verticalSlices - 2) * horizontalSlices) * 2) + (horizontalSlices * 2)) * 3;
    GLshort indices[numbOfTriangles];
    //converts the triangle vector into the array
    for (int j = 0; j < numbOfTriangles; j++) {
        indices[j] = triangles[j];
    }

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(vertArr) / (sizeof(vertArr[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertArr), vertArr, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    mesh.objectColor = color;
}

vector<float> getCircleVertices(float radius, int resolution) {
    vector<float> circleVerts;

    //push the center vertex
    circleVerts.push_back(0.0f); //x
    circleVerts.push_back(0.0f); //y
    circleVerts.push_back(0.0f); //z
    circleVerts.push_back(0.0f); //Normal x
    circleVerts.push_back(0.0f); //Normal y
    circleVerts.push_back(0.0f); //Normal z

    //texture for top center of circle
    circleVerts.push_back(0.5f);
    circleVerts.push_back(0.5f);

    const float PI = 3.1415926f;
    float step = 2 * PI / resolution;
    float radians;
    for (int i = 0; i < resolution; i++) {
        radians = i * step;
        circleVerts.push_back(cos(radians) * radius); //x
        circleVerts.push_back(sin(radians) * radius); //y
        circleVerts.push_back(0.0f); //z
        circleVerts.push_back(cos(radians)); //normalx
        circleVerts.push_back(sin(radians)); //normaly
        circleVerts.push_back(0.0f); //normalz

        //texture coords for top circle
        circleVerts.push_back(cos(radians)); //texture s
        circleVerts.push_back(sin(radians)); //texture t
    }
    return circleVerts;
}

vector<float> getCylinderVertices(float height, float upperRadius, float lowerRadius, float numberOfVerts) {
    vector<float> cylinderVerts;

    //push the top center vertex
    cylinderVerts.push_back(0.0f); //x
    cylinderVerts.push_back(0.0f); //y
    cylinderVerts.push_back(height / 2); //z
    cylinderVerts.push_back(0.0f); //Normal x
    cylinderVerts.push_back(height / 2); //Normal y
    cylinderVerts.push_back(0.0f); //Normal z

    //texture for top center of circle
    cylinderVerts.push_back(0.0f);
    cylinderVerts.push_back(1.0f);
    

    //Generate the vertices around the top circle
    const float PI = 3.1415926f;
    float step = 2 * PI / numberOfVerts;
    float radians;

    for (int i = 0; i < numberOfVerts; i++) {
        radians = i * step;
        cylinderVerts.push_back(cos(radians) * upperRadius); //x
        cylinderVerts.push_back(sin(radians) * upperRadius); //y
        cylinderVerts.push_back(height / 2); //z
        cylinderVerts.push_back(cos(radians)); //normalx
        cylinderVerts.push_back(sin(radians)); //normaly
        cylinderVerts.push_back((-height / 2.0f) + (i * height)); //normalz

        //texture coords for top circle
        cylinderVerts.push_back((float)i / numberOfVerts); //texture s
        cylinderVerts.push_back(1.0f); //texture t
    }

    //push the bottom center vertex
    cylinderVerts.push_back(0.0f); //x
    cylinderVerts.push_back(0.0f); //y
    cylinderVerts.push_back(-height / 2); //z
    cylinderVerts.push_back(0); //normalx
    cylinderVerts.push_back(0); //normaly
    cylinderVerts.push_back(-height/2); //normalz

    cylinderVerts.push_back(0.0f);
    cylinderVerts.push_back(0.0f);
    

    for (int j = 0; j < numberOfVerts; j++) {
        radians = j * step;

        cylinderVerts.push_back(cos(radians) * lowerRadius); //x
        cylinderVerts.push_back(sin(radians) * lowerRadius); //y
        cylinderVerts.push_back(-height / 2); //z
        cylinderVerts.push_back(cos(radians)); //normalx
        cylinderVerts.push_back(sin(radians)); //normaly
        cylinderVerts.push_back((-height / 2.0f) + (j * height)); //normalz

        //Texture coords for bottom circle
        cylinderVerts.push_back((float)j/numberOfVerts);
        cylinderVerts.push_back(0.0f);
        
    }

    return cylinderVerts;
}

vector<float> getTorusVertices(float torusRadius, float tubeRadius, int numberOfSlices, int tubeResolution) {
    vector<float> torusVerts;
    
    const float PI = 3.1415926f; //Constant for Pi
    
    float sliceRadians = 2 * PI / numberOfSlices; //The radians for each slice
    float tubeRadians = 2 * PI / tubeResolution; //The radians for the circle within the tube

    for (int i = 0; i < numberOfSlices; i+=2) {
        float currentSlice = i * sliceRadians;

        for (int j = 0; j < tubeResolution; j++) {
            float currentVertex = (j % tubeResolution) * tubeRadians;

            for (int k = 0; k < 2; k++) {
                float uu = currentSlice + k * sliceRadians;

                //Calculate the x, y, and z using the formula for the torus
                float x = (torusRadius + tubeRadius * cos(currentVertex)) * cos(uu);
                float y = (torusRadius + tubeRadius * cos(currentVertex)) * sin(uu);
                float z = tubeRadius * sin(currentVertex);

                float texturex = uu / (2 * PI);
                float texturey = currentVertex / (2 * PI);

                //Push the vertex data and the rgba data to the vector
                torusVerts.push_back(x);
                torusVerts.push_back(y);
                torusVerts.push_back(z);
                torusVerts.push_back(cos(currentVertex) * cos(uu)); //normalx
                torusVerts.push_back(cos(currentVertex) * sin(uu)); //normaly
                torusVerts.push_back(sin(currentVertex)); //normalz
                torusVerts.push_back(texturex);
                torusVerts.push_back(texturey);
            }
            currentVertex += tubeRadians;
        }
    }


    return torusVerts;
}

vector<float> getSphereVertices(float radius, int horizontalSlices, int verticalSlices) {
    vector<float> sphereVerts;

    
    const float PI = 3.1415926f; //Constant for Pi

    //north pole
    //Vertices
    sphereVerts.push_back(0); //x
    sphereVerts.push_back(0); //y
    sphereVerts.push_back(radius); //z

    //Normals
    sphereVerts.push_back(0);
    sphereVerts.push_back(0);
    sphereVerts.push_back(0);

    //Textures
    sphereVerts.push_back(0); //s
    sphereVerts.push_back(1); //t


    float lengthInv = 1.0f / radius;

    for (int i = 1; i < verticalSlices; i++) {
        float verticalAngle = (PI / 2) - (PI * ((float)i / verticalSlices));
        float z = radius * sin(verticalAngle);

        for (int j = 0; j < horizontalSlices; j++) {
            float horizontalAngle = (2 * PI) * ((float)j / horizontalSlices);
            float x = radius * cos(verticalAngle) * cos(horizontalAngle);
            float y = radius * cos(verticalAngle) * sin(horizontalAngle);

            //Vertices
            sphereVerts.push_back(x);
            sphereVerts.push_back(y);
            sphereVerts.push_back(z);

            //Normals
            sphereVerts.push_back(x * lengthInv);
            sphereVerts.push_back(y * lengthInv);
            sphereVerts.push_back(z * lengthInv);

            //Textures
            sphereVerts.push_back((float)j / horizontalSlices);
            sphereVerts.push_back((float)i / verticalSlices);
           
        }
    }

    //south pole
    //Vertices
    sphereVerts.push_back(0); //x
    sphereVerts.push_back(0); //y
    sphereVerts.push_back(-radius); //z

    //Normals
    sphereVerts.push_back(0);
    sphereVerts.push_back(0);
    sphereVerts.push_back(0);

    //Textures
    sphereVerts.push_back(0); //s
    sphereVerts.push_back(1); //t

    return sphereVerts;
    
}

//creates a vector of integers representing the triangle values for the cylinder
vector<GLushort> getCylinderTriangles(int numbOfVerts) {
    vector<GLushort> lines;

    //create all the connections in the upper circle, where the center is at index 0
    for (int i = 1; i < numbOfVerts; i++) {
        //create a triangle from the center of the circle to 2 points outside
        lines.push_back(0);
        lines.push_back(i);
        lines.push_back(i + 1);
    }
    
    //push the final triangle of the circle
    lines.push_back(0);
    lines.push_back(numbOfVerts);
    lines.push_back(1);

    int centerIndex = numbOfVerts + 1;
    //Do the same for the bottom circle
    for (int j = numbOfVerts + 2; j < numbOfVerts * 2 + 1; j++) {
        lines.push_back(centerIndex);
        lines.push_back(j);
        lines.push_back(j + 1);
    }

    //push the final triangle of the circle
    lines.push_back(centerIndex);
    lines.push_back(numbOfVerts * 2 + 1);
    lines.push_back(centerIndex + 1);

    
    int firstUpperVert = 1;
    int firstLowerVert = numbOfVerts + 2;
    //create all the triangles around the edges of the cylinder
    for (int k = 0; k < numbOfVerts - 1; k++) {
        //create a triangle for the left side of the rectangle
        lines.push_back(firstUpperVert + k);
        lines.push_back(firstLowerVert + k);
        lines.push_back(firstUpperVert + k + 1);

        //create a triangle for the right side of the rectangle
        lines.push_back(firstUpperVert + k + 1);
        lines.push_back(firstLowerVert + k);
        lines.push_back(firstLowerVert + k + 1);
    }

    //Add the last triangles to wrap around
    lines.push_back(numbOfVerts);
    lines.push_back((numbOfVerts * 2) + 1);
    lines.push_back(firstUpperVert);

    //create a triangle for the right side of the rectangle
    lines.push_back(firstUpperVert);
    lines.push_back((numbOfVerts * 2) + 1);
    lines.push_back(firstLowerVert);
    

    return lines;
}

vector<GLushort> getTorusTriangles(int numberOfSlices, int tubeResolution) {
    vector<GLushort> torusTriangles;

    int segmentStart = 0; //The vertex number of the start of a segment
    for (int i = 0; i < numberOfSlices; i += 2) {
        for (int j = 0; j < (tubeResolution * 2) - 1; j += 2) {
            int startingPoint = segmentStart + j; //The vertex of the start of the iteration
            int crossPoint = (segmentStart + (tubeResolution * 2) + j) % (tubeResolution * numberOfSlices); //The number of the vertex across the current slice

            //If the starting point is the last node before the edge, connect to the original vertex
            if (startingPoint == segmentStart + (tubeResolution * 2) - 2) {
                torusTriangles.push_back(startingPoint);
                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(segmentStart);

                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(segmentStart);
                torusTriangles.push_back(segmentStart + 1);

                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(crossPoint);
                torusTriangles.push_back(segmentStart + 1);

                torusTriangles.push_back(crossPoint);
                torusTriangles.push_back(segmentStart + 1);
                torusTriangles.push_back((segmentStart + (tubeResolution * 2)) % (tubeResolution * numberOfSlices));
            }
            else {
                //Base case, connect to the vertex next to the current vertex and above the current vertex
                torusTriangles.push_back(startingPoint);
                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(startingPoint + 2);

                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(startingPoint + 2);
                torusTriangles.push_back(startingPoint + 3);



                torusTriangles.push_back(startingPoint + 1);
                torusTriangles.push_back(crossPoint);
                torusTriangles.push_back(startingPoint + 3);

                torusTriangles.push_back(crossPoint);
                torusTriangles.push_back(startingPoint + 3);
                torusTriangles.push_back(crossPoint + 2);
            }
        }
        segmentStart += tubeResolution * 2;
    }


    return torusTriangles;


}

vector<GLushort> getCircleTriangles(int resolution) {
    vector<GLushort> triangles;
    for (int i = 1; i <= resolution; i++) {
        if (i == resolution) {
            triangles.push_back(0);
            triangles.push_back(i);
            triangles.push_back(1);
        }
        else {
            triangles.push_back(0);
            triangles.push_back(i);
            triangles.push_back(i + 1);
        }
    }
    return triangles;
}

vector<GLushort> getSphereTriangles(int horizontalSlices, int verticalSlices) {
    vector<GLushort> sphereTriangles;
    
    //create the triangles on the top pole
    for (int topIndex = 1; topIndex <= horizontalSlices; topIndex++) {
        //add top pole
        if (topIndex == horizontalSlices) {
            sphereTriangles.push_back(0); //top pole
            sphereTriangles.push_back(topIndex);
            sphereTriangles.push_back(1);
        }
        else {
            sphereTriangles.push_back(0); //top pole
            sphereTriangles.push_back(topIndex);
            sphereTriangles.push_back(topIndex + 1);
        }
    }

    for (int i = 0; i < verticalSlices - 2; i++) {
        int upperStartingPoint = (i * horizontalSlices) + 1; //Get the initial point
        int lowerStartingPoint = ((i + 1) * horizontalSlices) + 1;

        for (int j = 0; j < horizontalSlices; j++) {
            if (j == horizontalSlices - 1) {
                //Push the top triangle
                sphereTriangles.push_back(upperStartingPoint + j);
                sphereTriangles.push_back(lowerStartingPoint + j);
                sphereTriangles.push_back(upperStartingPoint);

                //push the bottom triangle
                sphereTriangles.push_back(upperStartingPoint);
                sphereTriangles.push_back(lowerStartingPoint + j);
                sphereTriangles.push_back(lowerStartingPoint);
            }else{
                //Push the top triangle
                sphereTriangles.push_back(upperStartingPoint + j);
                sphereTriangles.push_back(lowerStartingPoint + j);
                sphereTriangles.push_back(upperStartingPoint + j + 1);

                //push the bottom triangle
                sphereTriangles.push_back(upperStartingPoint + j + 1);
                sphereTriangles.push_back(lowerStartingPoint + j);
                sphereTriangles.push_back(lowerStartingPoint + j + 1);
            }
        }
    }
    int lastIndex = (verticalSlices - 1) * horizontalSlices + 1;
    int bottomRingStartingIndex = ((verticalSlices - 2) * horizontalSlices) + 1;

    //create the triangles on the top pole
    for (int bottomIndex = 0; bottomIndex < horizontalSlices; bottomIndex++) {
        //add top pole
        if (bottomIndex == horizontalSlices - 1) {
            sphereTriangles.push_back(lastIndex); //bottom pole
            sphereTriangles.push_back(bottomRingStartingIndex + bottomIndex);
            sphereTriangles.push_back(bottomRingStartingIndex);
        }
        else {
            sphereTriangles.push_back(lastIndex); //bottom pole
            sphereTriangles.push_back(bottomRingStartingIndex + bottomIndex);
            sphereTriangles.push_back(bottomRingStartingIndex + bottomIndex + 1);
        }
    }
    
    return sphereTriangles;
    
}

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}